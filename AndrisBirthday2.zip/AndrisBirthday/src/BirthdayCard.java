
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;
import javax.sound.sampled.*;
import java.io.File;

public class BirthdayCard extends JPanel implements ActionListener {
	
	private void playMusic() {
	    try {
	    	File file = new File("music/song2.wav");

	        AudioInputStream audio =
	            AudioSystem.getAudioInputStream(file);

	        Clip clip = AudioSystem.getClip();
	        clip.open(audio);
	        clip.loop(Clip.LOOP_CONTINUOUSLY);

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}

    private static final int WIDTH = 850;
    private static final int HEIGHT = 740;

    private final ArrayList<Confetti> confetti = new ArrayList<>();
    private final Random random = new Random();
    private double flamePhase = 0;

    public BirthdayCard() {
        setPreferredSize(new Dimension(WIDTH, HEIGHT));

        for (int i = 0; i < 100; i++) {
            confetti.add(new Confetti(random, WIDTH, HEIGHT));
        }

        new Timer(16, this).start();
        
        playMusic();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(
            RenderingHints.KEY_ANTIALIASING,
            RenderingHints.VALUE_ANTIALIAS_ON
        );

        // Праздничный градиент
        g2.setPaint(new GradientPaint(
            0, 0, new Color(255, 222, 160),
            0, HEIGHT, new Color(255, 133, 165)
        ));
        g2.fillRect(0, 0, WIDTH, HEIGHT);

        // Украшения фона
        g2.setColor(new Color(255, 255, 255, 48));
        g2.fillOval(-100, 260, 320, 320);
        g2.fillOval(650, 35, 250, 250);
        g2.fillOval(640, 420, 260, 260);

        // Падающие конфетти
        for (Confetti c : confetti) {
            g2.setColor(c.color);
            g2.fillOval(
                (int) c.x, (int) c.y, c.size, c.size
            );
        }

        // Поздравление
        drawCentered(
            g2,
            "С ДНЁМ РОЖДЕНИЯ!",
            76,
            new Font("SansSerif", Font.BOLD, 43),
            Color.WHITE
        );

        drawCentered(
            g2,
            "Пусть спина не хрустит,",
            131,
            new Font("SansSerif", Font.BOLD, 23),
            new Color(92, 42, 69)
        );

        drawCentered(
            g2,
            "колени не ноют на погоду,",
            166,
            new Font("SansSerif", Font.BOLD, 23),
            new Color(92, 42, 69)
        );

        drawCentered(
            g2,
            "а в паспорте будет написано,",
            201,
            new Font("SansSerif", Font.BOLD, 23),
            new Color(92, 42, 69)
        );

        drawCentered(
            g2,
            "что тебе всё ещё восемнадцать!",
            236,
            new Font("SansSerif", Font.BOLD, 23),
            new Color(92, 42, 69)
        );
        
        drawCentered(
        	    g2,
        	    "С днём рождения, братик! ❤️ 😘 💕",
        	    285,
        	    new Font("SansSerif", Font.BOLD, 27),
        	    new Color(160, 35, 85)
        	    
        	    );
        
        drawCentered(
        	    g2,
        	    "С любовью, Илона ❤️",
        	    665,
        	    new Font("SansSerif", Font.BOLD | Font.ITALIC, 25),
        	    new Color(145, 30, 85)
        	);
        

        drawCake(g2);
        g2.dispose();
    }

    // Центрирование текста
    private void drawCentered(
        Graphics2D g2,
        String text,
        int y,
        Font font,
        Color color
    ) {
        g2.setFont(font);

        int x = (
            WIDTH - g2.getFontMetrics().stringWidth(text)
        ) / 2;

        // Тень
        g2.setColor(new Color(112, 48, 74, 85));
        g2.drawString(text, x + 2, y + 3);

        // Основной текст
        g2.setColor(color);
        g2.drawString(text, x, y);
    }

    // Рисование праздничного торта
    private void drawCake(Graphics2D g2) {
        int cx = WIDTH / 2;

        // Подставка и тень
        g2.setColor(new Color(95, 43, 65, 65));
        g2.fillOval(cx - 205, 592, 410, 35);

        g2.setColor(new Color(255, 249, 252));
        g2.fillRoundRect(
            cx - 195, 574, 390, 28, 22, 22
        );

        g2.setColor(new Color(183, 116, 145));
        g2.drawRoundRect(
            cx - 195, 574, 390, 28, 22, 22
        );

        // Нижний ярус
        g2.setColor(new Color(115, 67, 61));
        g2.fillRoundRect(
            cx - 165, 465, 330, 116, 28, 28
        );

        // Розовая глазурь
        g2.setColor(new Color(250, 177, 205));
        g2.fillRoundRect(
            cx - 165, 463, 330, 39, 24, 24
        );

        g2.setColor(new Color(255, 218, 232));

        for (int x = cx - 140; x <= cx + 140; x += 35) {
            g2.fillOval(x - 10, 490, 20, 23);
        }

        // Декоративные точки
        g2.setColor(new Color(255, 236, 245));

        for (int x = cx - 130; x <= cx + 130; x += 32) {
            g2.fillOval(x - 5, 545, 10, 10);
        }

        // Верхний ярус
        g2.setColor(new Color(245, 225, 203));
        g2.fillRoundRect(
            cx - 116, 378, 232, 96, 26, 26
        );

        // Бирюзовая глазурь
        g2.setColor(new Color(130, 218, 216));
        g2.fillRoundRect(
            cx - 116, 377, 232, 32, 24, 24
        );

        g2.setColor(new Color(176, 240, 232));

        for (int x = cx - 92; x <= cx + 92; x += 31) {
            g2.fillOval(x - 9, 402, 18, 19);
        }

        // Украшения верхнего яруса
        g2.setColor(new Color(235, 144, 172));

        for (int x = cx - 90; x <= cx + 90; x += 30) {
            g2.fillOval(x - 4, 446, 8, 8);
        }

        // Три свечи с анимированным пламенем
        for (int dx : new int[]{-65, 0, 65}) {
            int x = cx + dx;

            g2.setColor(Color.WHITE);
            g2.fillRoundRect(
                x - 6, 338, 12, 40, 5, 5
            );

            // Полоски на свечах
            g2.setColor(new Color(255, 114, 145));

            for (int y = 343; y <= 368; y += 11) {
                g2.fillRect(x - 6, y, 12, 4);
            }

            // Колебание огня
            int sway = (int) (
                4 * Math.sin(flamePhase + dx)
            );

            g2.setColor(new Color(255, 138, 43));
            g2.fillOval(
                x - 8 + sway, 311, 16, 26
            );

            g2.setColor(new Color(255, 232, 97));
            g2.fillOval(
                x - 4 + sway, 319, 8, 16
            );
        }

        // Ягодки на верхушке
        g2.setColor(new Color(217, 59, 91));
        g2.fillOval(cx - 103, 368, 19, 15);
        g2.fillOval(cx + 84, 368, 19, 15);

        g2.setColor(new Color(89, 155, 91));
        g2.fillOval(cx - 94, 364, 9, 6);
        g2.fillOval(cx + 90, 364, 9, 6);
    }

    // Обновление анимации
    @Override
    public void actionPerformed(ActionEvent e) {
        for (Confetti c : confetti) {
            c.y += c.speed;

            if (c.y > HEIGHT) {
                c.y = -c.size;
                c.x = random.nextInt(WIDTH);
            }
        }

        flamePhase += 0.12;
        repaint();
    }

    // Класс для конфетти
    private static class Confetti {
        double x;
        double y;
        double speed;
        int size;
        Color color;

        Confetti(Random random, int width, int height) {
            x = random.nextInt(width);
            y = random.nextInt(height);

            speed = 0.8 + random.nextDouble() * 2.2;
            size = 4 + random.nextInt(7);

            color = new Color(
                70 + random.nextInt(186),
                70 + random.nextInt(186),
                70 + random.nextInt(186)
            );
        }
    }

    // Запуск открытки
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame(
                "Поздравительная открытка"
            );

            frame.setDefaultCloseOperation(
                JFrame.EXIT_ON_CLOSE
            );

            frame.setContentPane(new BirthdayCard());
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setResizable(false);
            frame.setVisible(true);
        });
    }
}